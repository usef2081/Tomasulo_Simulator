import React from 'react'

export default function output() {
  return (
    <div>output</div>
  )
}

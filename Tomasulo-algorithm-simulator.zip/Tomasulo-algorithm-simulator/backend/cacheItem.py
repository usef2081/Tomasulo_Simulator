class CacheItem:
    def __init__(self, validBit, value):
        self.validBit = validBit
        self.value = value
